package com.hireflow_ai_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HireflowAiBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(HireflowAiBackendApplication.class, args);
	}

}
